var user = {
    "email": "",
    "fullName": ""
}

export default user;