function submitForm(){
    document.getElementById("form").submit()
}
