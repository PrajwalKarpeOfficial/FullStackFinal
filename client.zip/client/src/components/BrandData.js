import BikanervalaBrand from "../images/BikanervalaBrand.webp"
import BiryaniBluesBrand from "../images/BiryaniBluesBrand.webp"
import BurgerKing from "../images/BurgerKing.webp"
import DominosBrand from "../images/DominosBrand.webp"
import HaldiramBrand from "../images/HaldiramBrand.webp"
import KFCBrand from "../images/KFCBrand.webp"
import McDonaldBrand from "../images/McDonaldBrand.webp"
import PizzaHutBrand from "../images/PizzaHutBrand.webp"
import SubwayBrand from "../images/SubwayBrand.webp"
import TheobromaBrand from "../images/TheobromaBrand.webp"

export const data = [BikanervalaBrand, BiryaniBluesBrand, BurgerKing, DominosBrand, HaldiramBrand, KFCBrand, McDonaldBrand, PizzaHutBrand, SubwayBrand, TheobromaBrand];