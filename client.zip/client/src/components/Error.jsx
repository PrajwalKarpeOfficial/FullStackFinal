import React from "react"

function Error(){
    return(
        <h1>Oops! This page does not exist.</h1>
    )
}

export default Error;