import image1 from '../images/im1.jpg'
import image2 from '../images/im2.jpg'
import image3 from '../images/im3.jpg'
import image4 from '../images/im4.jpg'
import image5 from '../images/im5.jpg'
import image6 from '../images/im6.jpg'

export const data = [image1, image2, image3,image4, image5, image6];